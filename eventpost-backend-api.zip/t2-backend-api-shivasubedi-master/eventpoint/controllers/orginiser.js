const User = require('../models/user');
const Post = require('../models/event');
const orginiser = require('../models/orginiser');
const Comment = require('../models/comment');

// Create a new orginiser
const orginiser = new orginiser({
    name: title,
    address: adress,
    date: date.now(),
    image: time,
  });

  // Save the post
  orginiser.save(function(err, orginiserpost) {  // callback function
    if (err) {
      return next(err);
    }
    res.json(orginiser);  // return the created orginiser
  });
};

/**
 * Fetch a single post by post ID
 *
 * @param req
 * @param res
 * @param next
 */
exports.fetchPost = function(req, res, next) {
    orginiser.findById({
    _id: req.params.id
  }, function(err, orginiser) {
    if (err) {
      console.log(err);
      return res.status(422).json({
        message: 'Error! Could not retrieve the post with the given post ID.'
      });
    }
    if (!orginiser) {
      return res.status(404).json({
        message: 'Error! The post with the given ID is not exist.'
      });
    }
    res.json(orginiser);  // return the single blog post
  });
};

/**
 * Check if current post can be updated or deleted by the authenticated user: The author can only make change to his/her own posts
 *
 * @param req
 * @param res
 * @param next
 */
exports.allowUpdateOrDelete = function(req, res, next) {

  // Require auth
  const user = req.user;

  // Find the post by post ID
  orginiser.findById({
    _id: req.params.id
  }, function(err, post) {

    if (err) {
      console.log(err);
      return res.status(422).json({
        message: 'Error! Could not retrieve the post with the given post ID.'
      });
    }

    // Check if the post exist
    if (!orginiser) {
      return res.status(404).json({
        message: 'Error! The post with the given ID is not exist.'
      });
    }
    console.log(orginiser.user._id);

    // Check if the user ID is equal to the author ID
    if (!user._id.equals(orginiser.user._id)) {
      return res.send({allowChange: false});
    }
    res.send({allowChange: true});
  });
};

/**
 * Edit/Update a post
 *
 * @param req
 * @param res
 * @param next
 */
exports.updatePost = function(req, res, next) {

  // Require auth
  const user = req.user;

  // Find the post by post ID
  orginiser.findById({
    _id: req.params.id
  }, function(err, orginiser) {

    if (err) {
      console.log(err);
      return res.status(422).json({
        message: 'Error! Could not retrieve the post with the given post ID.'
      });
    }

    // Check if the post exist
    if (!orginiser) {
      return res.status(404).json({
        message: 'Error! The post with the given ID is not exist.'
      });
    }

    // Make sure the user ID is equal to the author ID (Cause only the author can edit the post)
    // console.log(user._id);
    // console.log(post.authorId);
    if (!user._id.equals(orginiser.user._id)) {
      return res.status(422).json({
        message: 'Error! You have no authority to modify this orginiser.'
      });
    }





    // Save user
    orginiser.save(function(err, orginiser) {  // callback function
      if (err) {
        return next(err);
      }
      res.json(orginiser);  // return the updated post
    });
  });
};

/**
 * Delete a post by post ID
 *
 * @param req
 * @param res
 * @param next
 */
exports.deletePost = function(req, res, next) {

  // Require auth

  // Delete the post
  orginiser.findByIdAndRemove(req.params.id, function(err, orginiser) {
    if (err) {
      return next(err);
    }
    if (!orginiser) {
      return res.status(422).json({
        message: 'Error! The orginiser with the given ID is not exist.'
      });
    }
 // Return a success message
    res.json({
      message: 'The post has been deleted successfully!'
    });
  });
};

module.exports = router;