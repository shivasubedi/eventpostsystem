// Hold application secret and config
module.exports = {
  secret: 'DAnAkNmnk2jHONa4wVK0'//any secrett
};