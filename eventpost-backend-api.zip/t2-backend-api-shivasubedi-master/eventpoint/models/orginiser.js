const mongoose = require('mongoose');
//orginiser

const orginiserSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    address: {
        type: String,
        required: true
    },
    date: {
        type: date
        
    },
    image: {
        type: String
    }
});

module.exports = mongoose.model('orginiser', orginiserSchema);