import React from 'react';

// 404 error get page

export default () => (
  <div className="jumbotron jumbotron-fluid">
    <div className="container">
      <h1 className="display-3">Page Not Found</h1>
      <hr />
      <p className="lead">couldn't find data.</p>
    </div>
  </div>
);