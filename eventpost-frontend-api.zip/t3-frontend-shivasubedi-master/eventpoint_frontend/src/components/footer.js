import React from 'react';
//footer
export default () => {
  return (
    <footer className="footer">
      <div className="container">
        <span className="text-muted">Web api project shiva subedi</span>
      </div>
    </footer>
  );
}